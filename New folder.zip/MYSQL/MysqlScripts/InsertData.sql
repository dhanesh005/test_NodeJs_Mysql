INSERT INTO employees (first_name, last_name, department, email) 
VALUES ('Dhaneshwar', 'Swami', 'IT', 'DhaneshSwami@gmail.com');
VALUES ('PQR', 'XYZ', 'SUPPORT', 'PQR_XYZ@gmail.com');